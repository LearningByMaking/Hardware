in the file App_Board_V1.31.PLS (the top silk screen) you should see a label with the format:

V1.3 XXXX-YYYY

in a previous order, these had been replaced with

V1.2 SN001-YYYYY

I would like these to be replaced with

v.13 SN002-YYYYY


please contact me with any questions
Kevin John 
kj@universe.sonoma.edu
(707) 664-3460